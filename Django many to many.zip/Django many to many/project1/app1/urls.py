from django.urls import path
from app1.views import ownerview, carview, showcarView, showownerView, updateView, deleteView, carupdateView, cardeleteView

urlpatterns = [
    path('ov/', ownerview, name='ownerformurl'),
    path('cv/', carview, name= 'carformurl'),
    path('so/', showownerView, name='showownerurl'),
    path('sc/', showcarView, name='showcarurl'),
    path('uv/<int:id>/', updateView, name='updateurl'),
    path('dv/<int:id>/', deleteView, name='deleteurl'),
    path('uvv/<int:id>/', carupdateView, name='carupdateurl'),
    path('dvv/<int:id>/', cardeleteView, name='cardeleteurl'),
]