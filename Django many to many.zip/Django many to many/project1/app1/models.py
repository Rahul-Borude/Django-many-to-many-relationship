from django.db import models

# Create your models here.
class Owners(models.Model):
    oid = models.IntegerField(primary_key=True)
    fname = models.CharField(max_length=60)
    lname = models.CharField(max_length=60)

    def __str__(self):
        return self.fname

class cars(models.Model):
    cid = models.ManyToManyField(Owners)
    year = models.CharField(max_length=50)
    brand = models.CharField(max_length=50)
    model = models.CharField(max_length=50)

    def __str__(self):
        return self.cid