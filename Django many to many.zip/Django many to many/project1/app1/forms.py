from django import forms
from app1.models import Owners, cars

class OwnerForm(forms.ModelForm):
    class Meta:
        model = Owners
        fields = "__all__"

class CarForm(forms.ModelForm):
    class Meta:
        model = cars
        fields = "__all__"