from django.shortcuts import render, redirect
from app1.models import Owners, cars
from app1.forms import OwnerForm, CarForm
# Create your views here.

def ownerview(request):
    form = OwnerForm()
    template_name = "app1/ownerform.html"
    context = {'form':form}
    if request.method == "POST":
        form = OwnerForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, template_name, context)

def carview(request):
    form = CarForm()
    template_name = "app1/carform.html"
    context = {'form':form}
    if request.method == "POST":
        form = CarForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, template_name, context)

def showownerView(request):
    obj = Owners.objects.all()
    template_name = "app1/showowner.html"
    context = {'owner':obj}
    return render(request, template_name, context)

def showcarView(request):
    obj = cars.objects.all()
    template_name = "app1/showcar.html"
    context = {'car':obj}
    return render(request, template_name, context)

def updateView(request, id):
    obj = Owners.objects.get(oid = id)
    form = OwnerForm(instance=obj)
    template_name = "app1/ownerform.html"
    if request.method == "POST":
        form = OwnerForm(request.POST, instance=obj)
        print
        if form.is_valid():
            form.save()
            return redirect('showownerurl')
    context = {'form':form}
    return render(request, template_name, context)

def deleteView(request, id):
    obj = Owners.objects.get(oid = id)
    template_name = "app1/confirmation.html"
    context = {'data':obj}
    if request.method == "POST":
        obj.delete()
        return redirect('showownerurl')
    return render(request, template_name, context)

def carupdateView(request, id):
    obj = cars.objects.get(id = id)
    form = CarForm(instance=obj)
    template_name = "app1/carform.html"
    if request.method == "POST":
        form = CarForm(request.POST, instance=obj)
        print
        if form.is_valid():
            form.save()
            return redirect('showcarurl')
    context = {'form':form}
    return render(request, template_name, context)

def cardeleteView(request, id):
    obj = cars.objects.get(id = id)
    template_name = "app1/confirmation.html"
    context = {'data':obj}
    if request.method == "POST":
        obj.delete()
        return redirect('showcarurl')
    return render(request, template_name, context)